# Legion Kernel for atoll

## What's Included
- Legion Kernel for atoll platform with 5.10 BPF backports
- Image.gz - Kernel image for overlay-enabled device
- AnyKernel3 flasher script

## How to Flash

### LineageOS Users (No TWRP needed!)
1. Boot into LineageOS Recovery (Vol Up + Power)
2. Navigate: Apply update → Apply from ADB
3. On PC: `adb sideload legion-gta4xlve-YYYYMMDD.zip`
4. Reboot and enjoy!

### TWRP/OrangeFox Users
1. Boot into TWRP/OrangeFox recovery
2. Flash this ZIP file
3. Reboot and enjoy!

## Device Compatibility
- Samsung Galaxy Tab S6 Lite 2022 Wi-Fi & LTE (SM-P613/SM-P619), Galaxy A52 4G (SM-A525F), Galaxy A72 4G (SM-A725F)
- Models: gta4xlve, gta4xlvewifi, a52q, a72q
- Android 11-16 / LineageOS 18-23

## Credits
- @IamKavy47 for the script
- @frostg-012 for the kernel

---
