#!/sbin/sh
# AnyKernel3 Script for GTA4XLVE

## AnyKernel setup
# begin properties
properties() { '
kernel.string=Legion Kernel for atoll platform - Built for gta4xlveu (SM-P613/SM-P619)
do.devicecheck=0
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=gta4xlve
device.name2=gta4xl
device.name3=SM-P613
device.name4=gta4xlveu
device.name5=SM-P619
supported.versions=11-16
supported.patchlevels=
'; } # end properties

## AnyKernel boot install
# begin attributes
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;
patch_vbmeta_flag=auto;

# boot header version 2 for this device
boot_img_hdr_ver=2
# end attributes

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

## AnyKernel boot install
split_boot; # use split_boot to extract ramdisk and kernel

# Install kernel image
flash_boot;
## end boot install
